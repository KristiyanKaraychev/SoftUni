export function loadHomePage(context) {
    console.log("load Home Page");
    context.page.redirect("/dashboard");
}
